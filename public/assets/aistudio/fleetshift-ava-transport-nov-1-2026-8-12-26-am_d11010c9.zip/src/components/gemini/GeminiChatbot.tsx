import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, sendChatMessage } from '../../services/geminiClient';
import { Icon } from '../Icon';
import { FleetState } from '../../types';

interface GeminiChatbotProps {
  fleetState?: FleetState;
  driverName?: string;
  bus?: string;
  onClose?: () => void;
  initialRole?: 'dispatcher' | 'auditor' | 'mechanic' | 'general';
  compact?: boolean;
}

const ROLES = [
  {
    id: 'dispatcher' as const,
    name: 'Dispatcher & Ops',
    desc: 'Shift scheduling, UAE RTA transit rules, routes & passenger operations',
    icon: 'Bus',
    color: 'text-sky-400 bg-sky-500/15 border-sky-500/30',
  },
  {
    id: 'auditor' as const,
    name: 'Fleet Auditor',
    desc: 'Shift ODO verification, fuel consumption, mileage gaps & expense checks',
    icon: 'Calculator',
    color: 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30',
  },
  {
    id: 'mechanic' as const,
    name: 'Bus Mechanic',
    desc: 'Warning lights, diesel engines, brakes, tire wear & desert cooling',
    icon: 'Wrench',
    color: 'text-amber-400 bg-amber-500/15 border-amber-500/30',
  },
];

const MODELS = [
  {
    id: 'fast' as const,
    name: 'Fast',
    model: 'gemini-3.1-flash-lite',
    badge: 'Fastest Response',
    icon: 'Zap',
  },
  {
    id: 'general' as const,
    name: 'General',
    model: 'gemini-3.8-flash',
    badge: 'Standard Operations',
    icon: 'Sparkles',
  },
  {
    id: 'complex' as const,
    name: 'Complex',
    model: 'gemini-4-argon',
    badge: 'Deep Reasoning',
    icon: 'Bot',
  },
];

const SUGGESTED_PROMPTS: Record<string, string[]> = {
  dispatcher: [
    'What are UAE RTA maximum driving hours for commercial bus drivers?',
    'What is the standard procedure if a bus has an unexpected breakdown on Sheikh Zayed Road?',
    'How should a driver log an emergency inter-city passenger transfer?',
  ],
  auditor: [
    'How do I calculate fuel efficiency (km per liter) from shift ODO & fuel slips?',
    'What indicates an abnormal odometer jump between shift stages?',
    'Summarize fleet fuel expenses and VAT compliance points.',
  ],
  mechanic: [
    'What steps should a driver take if the ABS or air brake warning light turns on?',
    'Pre-trip bus safety checklist before starting morning shift in summer.',
    'How to check tire pressure and tread wear indicators on 50-passenger buses?',
  ],
  general: [
    'How does AVA Transport shift logging and offline sync work?',
    'Explain how to record watermarked odometer photos accurately.',
    'What should I do if my fuel receipt is faded or blurry?',
  ],
};

export function GeminiChatbot({
  fleetState,
  driverName,
  bus,
  onClose,
  initialRole = 'dispatcher',
  compact = false,
}: GeminiChatbotProps) {
  const [role, setRole] = useState<'dispatcher' | 'auditor' | 'mechanic' | 'general'>(initialRole);
  const [modelType, setModelType] = useState<'fast' | 'general' | 'complex'>('general');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      text: `Hello ${driverName ? driverName : 'Team'}! I am your **AVA Fleet AI Copilot**.\n\nI can assist with **shift logistics**, **odometer audits**, **fuel calculations**, and **vehicle safety**. You can also attach photos of meters or receipts directly to our conversation.`,
      timestamp: Date.now(),
      modelUsed: 'gemini-3.8-flash',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [attachedImage, setAttachedImage] = useState<{
    mimeType: string;
    data: string;
    previewUrl: string;
    name: string;
  } | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend ?? input).trim();
    if ((!text && !attachedImage) || loading) return;

    setError(null);
    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      text: text || 'Please inspect this attached image.',
      timestamp: Date.now(),
      image: attachedImage
        ? {
            mimeType: attachedImage.mimeType,
            data: attachedImage.data,
            previewUrl: attachedImage.previewUrl,
          }
        : undefined,
    };

    const newHistory = [...messages, userMessage];
    setMessages(newHistory);
    setInput('');
    const imagePayload = attachedImage
      ? { mimeType: attachedImage.mimeType, data: attachedImage.data }
      : undefined;
    setAttachedImage(null);
    setLoading(true);

    try {
      // Build lightweight fleet summary for server context
      const fleetContext = fleetState
        ? {
            activeDriversCount: fleetState.drivers.filter((d) => d.status === 'active').length,
            totalBuses: fleetState.buses.length,
            totalTrips: fleetState.trips.length,
            completedTrips: fleetState.trips.filter((t) => t.status === 'completed').length,
            currentVehicle: bus || null,
            activeUser: driverName || 'Admin Dispatcher',
          }
        : undefined;

      const serverMessages = newHistory.map((m) => ({
        role: m.role,
        text: m.text,
        image: m.image ? { mimeType: m.image.mimeType, data: m.image.data } : undefined,
      }));

      const res = await sendChatMessage({
        messages: serverMessages,
        role,
        modelType,
        fleetContext,
      });

      const assistantMessage: ChatMessage = {
        id: `asst-${Date.now()}`,
        role: 'assistant',
        text: res.reply,
        timestamp: Date.now(),
        modelUsed: res.modelUsed,
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err: any) {
      setError(err?.message || 'Failed to receive response from Gemini.');
    } finally {
      setLoading(false);
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('Please attach an image file (JPG, PNG, WebP).');
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      setError('Image must be under 15MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setAttachedImage({
        mimeType: file.type || 'image/jpeg',
        data: result,
        previewUrl: result,
        name: file.name,
      });
      setError(null);
    };
    reader.readAsDataURL(file);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const clearChat = () => {
    setMessages([
      {
        id: `welcome-${Date.now()}`,
        role: 'assistant',
        text: `Chat reset. I am ready as your **${ROLES.find((r) => r.id === role)?.name}** copilot. Ask me anything or upload an image!`,
        timestamp: Date.now(),
        modelUsed: MODELS.find((m) => m.id === modelType)?.model,
      },
    ]);
  };

  const currentRoleObj = ROLES.find((r) => r.id === role) || ROLES[0];
  const currentModelObj = MODELS.find((m) => m.id === modelType) || MODELS[1];

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
      {/* Header Bar */}
      <div className="px-4 py-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-sky-500/20 shrink-0">
            <Icon name="Bot" size={20} />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="font-bold text-sm text-white">AVA Gemini Copilot</span>
              <span className="text-[10px] font-semibold px-2 py-0.2 rounded-full bg-sky-500/15 text-sky-400 border border-sky-500/30">
                AI Powered
              </span>
            </div>
            <div className="text-[11px] text-slate-400 truncate">
              {currentRoleObj.name} • {currentModelObj.model}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={clearChat}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs transition-colors cursor-pointer"
            title="Clear Chat History"
          >
            <Icon name="RotateCcw" size={14} />
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white text-xs transition-colors cursor-pointer"
              title="Close Chat"
            >
              <Icon name="X" size={16} />
            </button>
          )}
        </div>
      </div>

      {/* Role and Model Selection Bar */}
      <div className="px-4 py-2.5 bg-slate-900/60 border-b border-slate-800/80 flex flex-col sm:flex-row gap-2 justify-between items-start sm:items-center text-xs">
        {/* Role Selector */}
        <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider shrink-0">
            Role:
          </span>
          {ROLES.map((r) => (
            <button
              key={r.id}
              onClick={() => setRole(r.id)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer shrink-0 ${
                role === r.id
                  ? 'bg-sky-500 text-white shadow-sm'
                  : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
              title={r.desc}
            >
              <Icon name={r.icon} size={12} />
              <span>{r.name}</span>
            </button>
          ))}
        </div>

        {/* Model Speed / Intelligence Selector */}
        <div className="flex items-center gap-1.5 shrink-0 w-full sm:w-auto justify-end">
          <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider shrink-0">
            Model:
          </span>
          <div className="flex bg-slate-800/90 rounded-lg p-0.5 border border-slate-700/60">
            {MODELS.map((m) => (
              <button
                key={m.id}
                onClick={() => setModelType(m.id)}
                className={`px-2 py-0.5 rounded-md text-[11px] font-semibold transition-all cursor-pointer ${
                  modelType === m.id
                    ? 'bg-sky-500 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title={`${m.model} (${m.badge})`}
              >
                {m.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Messages Scrollable Thread */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex gap-3 text-sm ${
              m.role === 'user' ? 'justify-end' : 'justify-start'
            } fade-in`}
          >
            {m.role === 'assistant' && (
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white shrink-0 mt-0.5 shadow-md shadow-sky-500/20">
                <Icon name="Bot" size={16} />
              </div>
            )}

            <div
              className={`max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-3 shadow-md relative group ${
                m.role === 'user'
                  ? 'bg-sky-600 text-white rounded-br-xs'
                  : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-bl-xs'
              }`}
            >
              {/* Optional Attached Image Preview */}
              {m.image && m.image.previewUrl && (
                <div className="mb-2 rounded-xl overflow-hidden border border-white/20 max-w-xs">
                  <img
                    src={m.image.previewUrl}
                    alt="Attached verification proof"
                    className="w-full max-h-48 object-cover"
                  />
                </div>
              )}

              {/* Message text with basic markdown formatting */}
              <div className="whitespace-pre-wrap leading-relaxed text-xs sm:text-sm">
                {m.text.split('\n').map((line, idx) => {
                  // Bold handling
                  const formatted = line.replace(
                    /\*\*(.*?)\*\*/g,
                    '<strong class="text-white font-semibold">$1</strong>'
                  );
                  return (
                    <p
                      key={idx}
                      className={line.startsWith('- ') ? 'ml-2 my-0.5' : 'my-1'}
                      dangerouslySetInnerHTML={{ __html: formatted }}
                    />
                  );
                })}
              </div>

              {/* Meta footer: Model & timestamp & copy button */}
              <div className="mt-2 pt-1.5 border-t border-slate-700/30 flex items-center justify-between text-[10px] text-slate-400 gap-2">
                <span>
                  {new Date(m.timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                  {m.modelUsed && (
                    <span className="ml-1.5 text-sky-300 font-mono">
                      • {m.modelUsed}
                    </span>
                  )}
                </span>
                <button
                  onClick={() => copyToClipboard(m.text, m.id)}
                  className="opacity-60 hover:opacity-100 transition-opacity p-1 rounded hover:bg-black/20 cursor-pointer"
                  title="Copy text"
                >
                  <Icon
                    name={copiedId === m.id ? 'Check' : 'Copy'}
                    size={12}
                    className={copiedId === m.id ? 'text-emerald-400' : ''}
                  />
                </button>
              </div>
            </div>

            {m.role === 'user' && (
              <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 shrink-0 mt-0.5">
                <Icon name="User" size={16} />
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="flex gap-3 text-sm justify-start fade-in">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white shrink-0 mt-0.5">
              <Icon name="Bot" size={16} />
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-2xl px-4 py-3 rounded-bl-xs text-xs text-slate-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
              <span>
                {currentRoleObj.name} thinking with {currentModelObj.model}...
              </span>
            </div>
          </div>
        )}

        {error && (
          <div className="p-3 bg-red-950/60 border border-red-500/40 rounded-xl text-xs text-red-300 flex items-center gap-2">
            <Icon name="AlertCircle" size={16} className="text-red-400 shrink-0" />
            <div className="flex-1">{error}</div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompts */}
      <div className="px-4 py-2 bg-slate-900/40 border-t border-slate-800/80 overflow-x-auto flex gap-2">
        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider self-center shrink-0">
          Try:
        </span>
        {(SUGGESTED_PROMPTS[role] || SUGGESTED_PROMPTS.general).map((p, i) => (
          <button
            key={i}
            onClick={() => handleSend(p)}
            disabled={loading}
            className="text-[11px] text-slate-300 hover:text-white bg-slate-800/90 hover:bg-slate-800 border border-slate-700/80 px-2.5 py-1 rounded-full whitespace-nowrap transition-colors cursor-pointer disabled:opacity-50"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Image Attachment Preview */}
      {attachedImage && (
        <div className="px-4 py-2 bg-slate-900 border-t border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <img
              src={attachedImage.previewUrl}
              alt="Attachment"
              className="w-10 h-10 object-cover rounded-lg border border-sky-500"
            />
            <div className="min-w-0">
              <div className="text-xs font-semibold text-white truncate">
                {attachedImage.name}
              </div>
              <div className="text-[10px] text-sky-400 font-mono">
                Image ready to send (will analyze with {currentModelObj.model})
              </div>
            </div>
          </div>
          <button
            onClick={() => setAttachedImage(null)}
            className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white cursor-pointer"
          >
            <Icon name="X" size={14} />
          </button>
        </div>
      )}

      {/* Input Form */}
      <div className="p-3 bg-slate-900 border-t border-slate-800">
        <div className="flex items-end gap-2 bg-slate-950 border border-slate-800 focus-within:border-sky-500 rounded-2xl p-1.5 transition-colors">
          <button
            onClick={() => fileInputRef.current?.click()}
            type="button"
            className="p-2 text-slate-400 hover:text-sky-400 hover:bg-slate-800/80 rounded-xl transition-colors cursor-pointer shrink-0"
            title="Attach dashboard photo or receipt"
          >
            <Icon name="Camera" size={18} />
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleImageSelect}
          />

          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={`Ask ${currentRoleObj.name} or describe image...`}
            rows={1}
            className="flex-1 bg-transparent border-0 focus:outline-none focus:ring-0 text-xs sm:text-sm text-white placeholder-slate-500 resize-none max-h-24 py-1.5"
          />

          <button
            onClick={() => handleSend()}
            disabled={(!input.trim() && !attachedImage) || loading}
            className="p-2 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-40 disabled:cursor-not-allowed text-white shadow-md shadow-sky-500/20 transition-all cursor-pointer shrink-0"
            title="Send Message"
          >
            <Icon name="Send" size={16} />
          </button>
        </div>
        <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1.5 px-1 font-mono">
          <span>Role: {currentRoleObj.name}</span>
          <span>Engine: {currentModelObj.model}</span>
        </div>
      </div>
    </div>
  );
}
