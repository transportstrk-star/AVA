import { useState, useRef } from 'react';
import { analyzeImageWithGemini, ExtractedImageData } from '../../services/geminiClient';
import { Icon } from '../Icon';

interface GeminiImageAnalyzerProps {
  onApplyOdometer?: (km: number) => void;
  onApplyExpense?: (data: {
    amount?: number;
    liters?: number;
    unitPrice?: number;
    vendor?: string;
    note?: string;
  }) => void;
  onClose?: () => void;
  bus?: string;
  driverName?: string;
  previousKm?: number | null;
  defaultTask?: 'odometer' | 'receipt' | 'damage' | 'general';
}

const TASK_PRESETS = [
  {
    id: 'odometer' as const,
    title: 'Odometer & Cluster',
    desc: 'Extract verified km reading & check dashboard warning indicators',
    icon: 'Gauge',
    color: 'text-sky-400 bg-sky-500/15 border-sky-500/30',
  },
  {
    id: 'receipt' as const,
    title: 'Fuel Slip / Receipt OCR',
    desc: 'Extract ADNOC/ENOC station, liters, rate, total AED & invoice number',
    icon: 'Fuel',
    color: 'text-amber-400 bg-amber-500/15 border-amber-500/30',
  },
  {
    id: 'damage' as const,
    title: 'Bus Inspection / Damage',
    desc: 'Detect body dents, scratches, tire tread wear & safety status',
    icon: 'Wrench',
    color: 'text-red-400 bg-red-500/15 border-red-500/30',
  },
  {
    id: 'general' as const,
    title: 'Custom Vision Audit',
    desc: 'Ask custom multi-modal questions about any vehicle document or photo',
    icon: 'Sparkles',
    color: 'text-violet-400 bg-violet-500/15 border-violet-500/30',
  },
];

export function GeminiImageAnalyzer({
  onApplyOdometer,
  onApplyExpense,
  onClose,
  bus,
  driverName,
  previousKm,
  defaultTask = 'odometer',
}: GeminiImageAnalyzerProps) {
  const [taskType, setTaskType] = useState<'odometer' | 'receipt' | 'damage' | 'general'>(defaultTask);
  const [customPrompt, setCustomPrompt] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageName, setImageName] = useState<string>('');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisText, setAnalysisText] = useState<string | null>(null);
  const [modelUsed, setModelUsed] = useState<string>('gemini-4-argon');
  const [extractedData, setExtractedData] = useState<ExtractedImageData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const cameraInputRef = useRef<HTMLInputElement | null>(null);

  const handleFile = (file?: File | null) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Please select an image file (JPEG, PNG, WebP).');
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      setError('File size exceeds 20MB limit.');
      return;
    }

    setError(null);
    setAnalysisText(null);
    setExtractedData(null);
    setImageName(file.name);

    const reader = new FileReader();
    reader.onload = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const runAnalysis = async () => {
    if (!imagePreview || analyzing) return;

    setAnalyzing(true);
    setError(null);
    setAnalysisText(null);
    setExtractedData(null);

    try {
      const res = await analyzeImageWithGemini({
        image: imagePreview,
        taskType,
        prompt: customPrompt.trim() || undefined,
        bus,
        driverName,
        previousKm,
      });

      setAnalysisText(res.analysis);
      setModelUsed(res.modelUsed || 'gemini-4-argon');
      setExtractedData(res.extracted || null);
    } catch (err: any) {
      setError(err?.message || 'Gemini 4 Argon image analysis failed.');
    } finally {
      setAnalyzing(false);
    }
  };

  const copyAnalysis = () => {
    if (!analysisText) return;
    navigator.clipboard.writeText(analysisText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
      {/* Header */}
      <div className="px-5 py-3.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center text-white shadow-lg shadow-rose-500/20">
            <Icon name="Scan" size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-sm sm:text-base text-white">
                Gemini Vision Intelligence
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/30 text-[10px] font-mono font-semibold">
                gemini-4-argon
              </span>
            </div>
            <p className="text-xs text-slate-400">
              High-precision OCR and vehicle multimodal diagnostics
            </p>
          </div>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <Icon name="X" size={18} />
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5">
        {/* Task Preset Selector */}
        <div>
          <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 block">
            Select Analysis Type
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {TASK_PRESETS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTaskType(t.id)}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  taskType === t.id
                    ? 'bg-sky-500/10 border-sky-500 text-white shadow-md shadow-sky-500/10'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div
                    className={`p-1.5 rounded-lg ${
                      taskType === t.id ? 'bg-sky-500 text-white' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Icon name={t.icon} size={16} />
                  </div>
                  {taskType === t.id && (
                    <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
                  )}
                </div>
                <div>
                  <div className="font-semibold text-xs text-white leading-snug">
                    {t.title}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1 line-clamp-2">
                    {t.desc}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Upload or Capture Area */}
        <div className="card p-4 border border-slate-800 bg-slate-900/60">
          {!imagePreview ? (
            <div className="border-2 border-dashed border-slate-700 hover:border-sky-500/60 rounded-2xl p-6 text-center transition-colors">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-slate-800 flex items-center justify-center text-slate-400 mb-3">
                <Icon name="Camera" size={28} className="text-sky-400" />
              </div>
              <h3 className="font-semibold text-sm text-white mb-1">
                Upload or Take Dashboard / Receipt Photo
              </h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
                Capture high-resolution photo for Gemini 4 Argon image understanding.
              </p>
              <div className="flex flex-col sm:flex-row gap-2 justify-center max-w-xs mx-auto">
                <button
                  onClick={() => cameraInputRef.current?.click()}
                  className="py-2.5 px-4 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-sky-500/20 cursor-pointer transition-all"
                >
                  <Icon name="Camera" size={16} /> Snap Photo
                </button>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 border border-slate-700 cursor-pointer transition-all"
                >
                  <Icon name="Upload" size={16} /> Upload Image
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="relative rounded-2xl overflow-hidden bg-black max-h-72 flex items-center justify-center border border-slate-700">
                <img
                  src={imagePreview}
                  alt="Inspection target"
                  className="max-h-72 w-full object-contain"
                />
                <button
                  onClick={() => {
                    setImagePreview(null);
                    setAnalysisText(null);
                    setExtractedData(null);
                  }}
                  className="absolute top-2.5 right-2.5 p-1.5 rounded-lg bg-black/70 hover:bg-black text-white cursor-pointer transition-colors"
                  title="Remove Image"
                >
                  <Icon name="X" size={16} />
                </button>
                <div className="absolute bottom-2 left-2 bg-black/75 backdrop-blur px-2.5 py-1 rounded-lg text-[10px] font-mono text-slate-300">
                  {imageName || 'Target Image'}
                </div>
              </div>

              {/* Optional Custom Instructions */}
              <div>
                <input
                  type="text"
                  value={customPrompt}
                  onChange={(e) => setCustomPrompt(e.target.value)}
                  placeholder="Optional prompt: e.g. 'Is the tire safe?' or 'Check tax invoice number'"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500"
                />
              </div>

              {/* Analyze CTA */}
              <button
                onClick={runAnalysis}
                disabled={analyzing}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-sky-500 via-indigo-500 to-rose-500 hover:opacity-95 disabled:opacity-50 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-sky-500/20 cursor-pointer transition-all"
              >
                {analyzing ? (
                  <>
                    <Icon name="RefreshCw" size={16} className="animate-spin" />
                    <span>Analyzing with Gemini 4 Argon...</span>
                  </>
                ) : (
                  <>
                    <Icon name="Sparkles" size={16} />
                    <span>Analyze Image with gemini-4-argon</span>
                  </>
                )}
              </button>
            </div>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => handleFile(e.target.files?.[0])}
          />
          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={(e) => handleFile(e.target.files?.[0])}
          />
        </div>

        {/* Error message */}
        {error && (
          <div className="p-3.5 bg-red-950/60 border border-red-500/40 rounded-xl text-xs text-red-300 flex items-center gap-2">
            <Icon name="AlertCircle" size={16} className="text-red-400 shrink-0" />
            <div className="flex-1">{error}</div>
          </div>
        )}

        {/* Extracted Data Action Cards */}
        {extractedData && (
          <div className="card p-4 border border-emerald-500/40 bg-emerald-950/20 space-y-3 fade-in">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                <Icon name="CheckCircle" size={16} /> Verified Information Extracted
              </span>
              <span className="text-[10px] text-slate-400 font-mono">1-Click Auto-Fill</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {/* Odometer detected */}
              {extractedData.odometer != null && (
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-700/80 flex items-center justify-between gap-2">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase tracking-wide block">
                      Detected ODO Reading
                    </span>
                    <span className="font-mono text-base font-bold text-sky-400">
                      {extractedData.odometer.toLocaleString()} km
                    </span>
                  </div>
                  {onApplyOdometer && (
                    <button
                      onClick={() => onApplyOdometer(extractedData.odometer!)}
                      className="px-3 py-1.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-white font-semibold text-xs cursor-pointer shadow-md shadow-sky-500/20"
                    >
                      Use as ODO
                    </button>
                  )}
                </div>
              )}

              {/* Fuel amount / liters detected */}
              {(extractedData.amount != null || extractedData.liters != null) && (
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-700/80 flex items-center justify-between gap-2">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase tracking-wide block">
                      Detected Expense
                    </span>
                    <span className="font-mono text-base font-bold text-amber-400">
                      {extractedData.amount != null ? `${extractedData.amount.toFixed(2)} AED` : ''}
                      {extractedData.liters != null && (
                        <span className="text-xs font-normal text-slate-300 ml-1">
                          ({extractedData.liters} L)
                        </span>
                      )}
                    </span>
                    {extractedData.vendor && (
                      <div className="text-[10px] text-slate-400 truncate">
                        Station: {extractedData.vendor}
                      </div>
                    )}
                  </div>
                  {onApplyExpense && (
                    <button
                      onClick={() =>
                        onApplyExpense({
                          amount: extractedData.amount || undefined,
                          liters: extractedData.liters || undefined,
                          unitPrice: extractedData.unitPrice || undefined,
                          vendor: extractedData.vendor,
                          note: extractedData.vendor ? `${extractedData.vendor} fuel slip` : undefined,
                        })
                      }
                      className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer shadow-md shadow-amber-500/20"
                    >
                      Fill Expense
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Detailed Analysis Output */}
        {analysisText && (
          <div className="card p-5 border border-slate-800 shadow-xl space-y-3 fade-in">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <Icon name="FileText" size={16} className="text-sky-400" />
                <h3 className="font-semibold text-sm text-white">Analysis Findings</h3>
                <span className="text-[10px] text-slate-500 font-mono">
                  Engine: {modelUsed}
                </span>
              </div>
              <button
                onClick={copyAnalysis}
                className="text-xs text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
              >
                <Icon name={copied ? 'Check' : 'Copy'} size={13} className={copied ? 'text-emerald-400' : ''} />
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <div className="text-xs sm:text-sm text-slate-300 space-y-1.5 leading-relaxed">
              {analysisText.split('\n').map((line, idx) => {
                const formatted = line.replace(
                  /\*\*(.*?)\*\*/g,
                  '<strong class="text-white font-semibold">$1</strong>'
                );
                return (
                  <p
                    key={idx}
                    className={line.startsWith('- ') ? 'ml-3 my-0.5' : 'my-1'}
                    dangerouslySetInnerHTML={{ __html: formatted }}
                  />
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
