import { useState, useRef } from 'react';
import { Driver, FleetState } from '../../types';
import { ADMIN_PASS } from '../../utils/storage';
import { Icon } from '../Icon';
import { googleSignIn, isUnauthorizedDomainError, demoSignIn } from '../../services/googleWorkspace';

interface LoginScreenProps {
  state: FleetState;
  onDriverLogin: (driver: Driver) => void;
  onAdminLogin: () => void;
  forceDriver?: boolean;
  forceAdmin?: boolean;
}

export function LoginScreen({
  state,
  onDriverLogin,
  onAdminLogin,
  forceDriver = false,
  forceAdmin = false,
}: LoginScreenProps) {
  const initialMode = forceDriver ? 'driver' : forceAdmin ? 'admin' : null;
  const [mode, setMode] = useState<'driver' | 'admin' | null>(initialMode);
  const [selectedDriver, setSelectedDriver] = useState('');
  const [driverPin, setDriverPin] = useState('');
  const [adminPass, setAdminPass] = useState('');
  const [error, setError] = useState('');
  const [showForgotPin, setShowForgotPin] = useState(false);
  const [googleLoggingIn, setGoogleLoggingIn] = useState(false);
  const [unauthorizedDomain, setUnauthorizedDomain] = useState<string | null>(null);
  const [copiedDomain, setCopiedDomain] = useState(false);
  const pinRef = useRef<HTMLInputElement | null>(null);

  const activeDrivers = (state.drivers || []).filter((d) => d.status === 'active');

  const handleGoogleLogin = async () => {
    setGoogleLoggingIn(true);
    setError('');
    setUnauthorizedDomain(null);
    try {
      const res = await googleSignIn();
      if (res) {
        onAdminLogin();
      }
    } catch (e: any) {
      if (isUnauthorizedDomainError(e)) {
        const hostname = typeof window !== 'undefined' ? window.location.hostname : 'preview';
        setUnauthorizedDomain(hostname);
      } else {
        setError(e.message || 'Google sign-in failed');
      }
    } finally {
      setGoogleLoggingIn(false);
    }
  };

  const handleCopyDomain = async (domain: string) => {
    try {
      await navigator.clipboard.writeText(domain);
      setCopiedDomain(true);
      setTimeout(() => setCopiedDomain(false), 2500);
    } catch {
      // ignore
    }
  };

  const handleContinueAsDemoAdmin = () => {
    demoSignIn('transportstrk@gmail.com');
    setUnauthorizedDomain(null);
    onAdminLogin();
  };

  const tryAdmin = () => {
    if (adminPass === ADMIN_PASS) {
      onAdminLogin();
    } else {
      setError('Incorrect passcode. Contact fleet management.');
    }
  };

  const tryDriver = () => {
    const d = state.drivers.find((x) => x.id === selectedDriver);
    if (!d || d.status !== 'active') {
      setError('Please select an active driver');
      return;
    }
    const expected = String(d.pin || '').trim();
    const entered = String(driverPin || '').trim();
    if (!entered) {
      setError('Enter your PIN');
      return;
    }
    if (entered !== expected) {
      setError('Incorrect PIN');
      setDriverPin('');
      if (pinRef.current) pinRef.current.focus();
      return;
    }
    setError('');
    onDriverLogin(d);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-slate-100">
      <div className="text-center mb-8 max-w-sm">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-sky-500/20 to-emerald-500/20 border border-sky-500/30 text-sky-400 flex items-center justify-center mx-auto mb-3 shadow-xl shadow-sky-500/10">
          <Icon name="Bus" size={32} />
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-white flex items-center justify-center gap-2">
          <span>AVA APP</span>
          <span className="text-[10px] bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-medium tracking-wide">
            FLEET
          </span>
        </h1>
        <p className="text-slate-400 text-xs mt-1.5 leading-relaxed">
          {forceDriver
            ? 'Driver Portal · AVA Transport'
            : forceAdmin
            ? 'Admin Control Center · AVA Transport'
            : 'AVA Transport & Rental · Fleet Management System'}
        </p>
      </div>

      {!mode && (
        <div className="w-full max-w-sm space-y-3 fade-in">
          <button
            onClick={() => setMode('driver')}
            className="w-full card card-hover p-5 text-left flex items-center gap-4 border border-slate-800 hover:border-sky-500/50 transition-all cursor-pointer shadow-lg"
          >
            <div className="w-12 h-12 rounded-xl bg-sky-500/20 flex items-center justify-center text-sky-400 shrink-0">
              <Icon name="User" size={24} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-white text-base">Driver Portal</div>
              <div className="text-xs text-slate-400 mt-0.5">
                Log shifts, ODO meters, watermarked photos & receipts
              </div>
            </div>
            <Icon name="ChevronRight" size={18} className="text-slate-500" />
          </button>

          <button
            onClick={() => setMode('admin')}
            className="w-full card card-hover p-5 text-left flex items-center gap-4 border border-slate-800 hover:border-violet-500/50 transition-all cursor-pointer shadow-lg"
          >
            <div className="w-12 h-12 rounded-xl bg-violet-500/20 flex items-center justify-center text-violet-400 shrink-0">
              <Icon name="Shield" size={24} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-white text-base">Admin Control Center</div>
              <div className="text-xs text-slate-400 mt-0.5">
                Roster, PIN reset, fleet buses & master audit trail
              </div>
            </div>
            <Icon name="ChevronRight" size={18} className="text-slate-500" />
          </button>

          {/* Google Workspace Cloud Login */}
          <button
            onClick={handleGoogleLogin}
            disabled={googleLoggingIn}
            className="w-full py-3.5 px-4 rounded-2xl bg-white hover:bg-slate-100 text-slate-900 font-semibold text-xs flex items-center justify-center gap-2.5 shadow-lg shadow-white/5 transition-all cursor-pointer disabled:opacity-50"
          >
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>{googleLoggingIn ? 'Connecting to Google...' : 'Sign in with Google (Admin Cloud)'}</span>
          </button>

          <div className="text-[11px] text-slate-500 text-center flex items-center justify-center gap-1.5">
            <span>Fast Passcode Access:</span>
            <button
              onClick={() => {
                setMode('admin');
                setAdminPass(ADMIN_PASS);
                setError('');
              }}
              className="text-violet-400 hover:text-violet-300 font-mono font-medium underline cursor-pointer"
            >
              admin123
            </button>
          </div>

          {error && (
            <div className="text-red-400 text-xs flex items-center gap-1.5 bg-red-500/10 p-2.5 rounded-lg border border-red-500/20">
              <Icon name="AlertCircle" size={14} className="shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Portal Security Footer Note */}
          <div className="mt-8 pt-6 border-t border-slate-800/80 text-center space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-sky-500/15 via-indigo-500/15 to-rose-500/15 border border-sky-500/30 text-[11px] text-sky-300 font-medium">
              <Icon name="Sparkles" size={13} className="text-sky-400" />
              <span>Gemini 4 Argon Vision & AI Chatbot Active</span>
            </div>
            <div className="text-[11px] text-slate-500 font-medium flex items-center justify-center gap-1.5">
              <Icon name="Shield" size={13} className="text-emerald-400" />
              <span>AVA Transport & Rental · Enterprise Fleet Portal</span>
            </div>
            <div className="text-[10px] text-slate-600">
              Authorized personnel only · Real-time sync & audit tracking
            </div>
          </div>
        </div>
      )}

      {mode === 'driver' && (
        <div className="w-full max-w-sm card p-6 fade-in border border-slate-800 shadow-2xl">
          {!forceDriver && (
            <button
              onClick={() => {
                setMode(null);
                setError('');
                setDriverPin('');
              }}
              className="text-xs text-slate-400 hover:text-white mb-4 flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Icon name="ArrowLeft" size={14} /> Back to Launcher
            </button>
          )}

          <h2 className="font-bold text-lg text-white mb-1">Driver Login</h2>
          <p className="text-xs text-slate-400 mb-4">Select your profile and enter your 4-digit PIN</p>

          <label className="text-xs text-slate-400 block mb-1.5 font-medium">Driver Profile</label>
          <select
            value={selectedDriver}
            onChange={(e) => {
              setSelectedDriver(e.target.value);
              setError('');
              setDriverPin('');
            }}
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-3 text-sm text-white mb-4 cursor-pointer"
          >
            <option value="">— Select Driver —</option>
            {activeDrivers.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} · {d.bus}
              </option>
            ))}
          </select>

          <label className="text-xs text-slate-400 block mb-1.5 font-medium">Security PIN</label>
          <input
            ref={pinRef}
            type="password"
            inputMode="numeric"
            pattern="[0-9]*"
            maxLength={6}
            value={driverPin}
            onChange={(e) => {
              setDriverPin(e.target.value.replace(/\D/g, ''));
              setError('');
            }}
            onKeyDown={(e) => e.key === 'Enter' && tryDriver()}
            placeholder="••••"
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-3 mb-4 text-center text-2xl tracking-[0.4em] font-semibold text-white placeholder-slate-600 font-mono"
            autoComplete="off"
          />

          {error && (
            <div className="text-red-400 text-xs mb-3.5 flex items-center gap-1.5 bg-red-500/10 p-2.5 rounded-lg border border-red-500/20">
              <Icon name="AlertCircle" size={14} className="shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button
            onClick={tryDriver}
            disabled={!selectedDriver}
            className="w-full py-3.5 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold text-sm cursor-pointer shadow-lg shadow-sky-500/20 transition-all"
          >
            Unlock Portal
          </button>

          <button
            type="button"
            onClick={() => setShowForgotPin(true)}
            className="w-full mt-3 text-xs text-slate-400 hover:text-sky-400 py-1 cursor-pointer transition-colors"
          >
            Forgot PIN?
          </button>

          <div className="mt-4 pt-4 border-t border-slate-800/80 text-[11px] text-slate-500 text-center">
            Authorized AVA Transport drivers only. Contact dispatch for assistance.
          </div>
        </div>
      )}

      {showForgotPin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center modal-backdrop p-4 bg-black/80">
          <div className="card w-full max-w-sm p-6 fade-in border border-slate-800 shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center mx-auto mb-3">
              <Icon name="KeyRound" size={24} />
            </div>
            <h3 className="font-bold text-center text-lg mb-2 text-white">Forgot your PIN?</h3>
            <p className="text-xs text-slate-400 text-center mb-4 leading-relaxed">
              For security, driver PINs are centrally managed. Contact your AVA Transport fleet manager or administrator to request a PIN reset.
            </p>
            <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-3 mb-4 text-xs text-slate-300">
              <div className="font-semibold text-slate-200 mb-1.5 flex items-center gap-1.5">
                <Icon name="Shield" size={14} className="text-sky-400" /> Admin Reset Procedure:
              </div>
              <ol className="list-decimal list-inside space-y-1 text-slate-400">
                <li>Admin logs into Admin Control Center</li>
                <li>Navigates to the <strong className="text-slate-200">Roster</strong> tab</li>
                <li>Clicks <strong className="text-amber-400">Reset PIN</strong> on your profile</li>
                <li>Provides you with the new 4-digit temporary PIN</li>
              </ol>
            </div>
            <button
              onClick={() => setShowForgotPin(false)}
              className="w-full py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold text-sm cursor-pointer shadow-lg shadow-sky-500/20"
            >
              Understood
            </button>
          </div>
        </div>
      )}

      {/* Firebase Unauthorized Domain Modal with 1-Click Fast Unlock */}
      {unauthorizedDomain && (
        <div className="fixed inset-0 z-50 flex items-center justify-center modal-backdrop p-4 bg-black/85">
          <div className="card w-full max-w-md p-6 fade-in border border-amber-500/40 shadow-2xl bg-slate-900 text-slate-100">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto mb-3 border border-amber-500/30">
              <Icon name="ShieldAlert" size={26} />
            </div>
            <h3 className="font-bold text-center text-lg mb-1 text-white">Firebase Domain Authorization Notice</h3>
            <p className="text-xs text-slate-300 text-center mb-4 leading-relaxed">
              Google OAuth popup sign-in requires this preview host to be added to Firebase Authorized Domains.
            </p>

            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 mb-4 space-y-2">
              <div className="text-[11px] text-slate-400 font-medium flex items-center justify-between">
                <span>Current Preview Host:</span>
                <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                  Origin URL
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={unauthorizedDomain}
                  className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs font-mono text-amber-300 select-all"
                />
                <button
                  onClick={() => handleCopyDomain(unauthorizedDomain)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200 cursor-pointer shrink-0 transition-colors"
                >
                  {copiedDomain ? 'Copied!' : 'Copy'}
                </button>
              </div>
            </div>

            {/* Quick 1-Click Actions */}
            <div className="space-y-2 mb-4">
              <button
                onClick={() => {
                  setUnauthorizedDomain(null);
                  onAdminLogin();
                }}
                className="w-full py-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-semibold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-violet-600/25 transition-all"
              >
                <Icon name="KeyRound" size={15} />
                <span>Instant Access: Unlock Admin via Passcode (admin123)</span>
              </button>

              <button
                onClick={handleContinueAsDemoAdmin}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-medium text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Icon name="Sparkles" size={14} className="text-sky-400" />
                <span>Continue as Admin (transportstrk@gmail.com)</span>
              </button>
            </div>

            {/* Instructions to authorize in Firebase Console */}
            <div className="text-[11px] text-slate-400 bg-slate-950/60 border border-slate-800/80 rounded-xl p-3 mb-4 space-y-1">
              <div className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Icon name="ExternalLink" size={12} className="text-amber-400" /> To enable live Google Sign-In:
              </div>
              <ol className="list-decimal list-inside space-y-0.5 text-slate-400 text-[10px]">
                <li>Open Firebase Console (<span className="text-slate-300 font-mono">gen-lang-client-0797790394</span>)</li>
                <li>Go to <strong>Authentication</strong> → <strong>Settings</strong> → <strong>Authorized domains</strong></li>
                <li>Click <strong>Add domain</strong> and paste the host above</li>
              </ol>
            </div>

            <button
              onClick={() => setUnauthorizedDomain(null)}
              className="w-full py-2 text-xs text-slate-400 hover:text-white cursor-pointer transition-colors text-center"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {mode === 'admin' && (
        <div className="w-full max-w-sm card p-6 fade-in border border-slate-800 shadow-2xl">
          {!forceAdmin && (
            <button
              onClick={() => {
                setMode(null);
                setError('');
                setAdminPass('');
              }}
              className="text-xs text-slate-400 hover:text-white mb-4 flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Icon name="ArrowLeft" size={14} /> Back to Launcher
            </button>
          )}
          <h2 className="font-bold text-lg text-white mb-1">Admin Passcode</h2>
          <p className="text-xs text-slate-400 mb-3">Enter master passcode for fleet control</p>

          <div className="mb-4 p-2.5 rounded-xl bg-violet-500/10 border border-violet-500/20 text-xs text-violet-300 flex items-center justify-between">
            <span className="text-[11px]">Default Passcode: <strong className="font-mono text-white">admin123</strong></span>
            <button
              onClick={() => setAdminPass(ADMIN_PASS)}
              className="text-[10px] bg-violet-500/20 hover:bg-violet-500/30 text-violet-200 px-2 py-0.5 rounded font-medium cursor-pointer transition-colors"
            >
              Autofill
            </button>
          </div>

          <input
            type="password"
            value={adminPass}
            onChange={(e) => {
              setAdminPass(e.target.value);
              setError('');
            }}
            onKeyDown={(e) => e.key === 'Enter' && tryAdmin()}
            placeholder="Enter passcode"
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-3 mb-4 text-center tracking-widest text-lg font-mono text-white placeholder-slate-600"
            autoFocus
          />
          {error && (
            <div className="text-red-400 text-xs mb-3.5 flex items-center gap-1.5 bg-red-500/10 p-2.5 rounded-lg border border-red-500/20">
              <Icon name="AlertCircle" size={14} className="shrink-0" />
              <span>{error}</span>
            </div>
          )}
          <button
            onClick={tryAdmin}
            className="w-full py-3.5 rounded-xl bg-violet-500 hover:bg-violet-400 text-white font-semibold text-sm cursor-pointer shadow-lg shadow-violet-500/20 transition-all"
          >
            Unlock Control Center
          </button>
          <p className="text-[11px] text-slate-500 text-center mt-3">
            Authorized AVA fleet management access only
          </p>
        </div>
      )}
    </div>
  );
}
