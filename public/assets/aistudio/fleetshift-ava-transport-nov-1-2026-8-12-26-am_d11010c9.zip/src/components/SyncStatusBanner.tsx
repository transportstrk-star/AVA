import { useState, useEffect } from 'react';
import { QueueItem } from '../types';
import { Icon } from './Icon';

interface SyncStatusBannerProps {
  online: boolean;
  queue: QueueItem[];
  syncing?: boolean;
  onSyncNow?: () => void;
  onToggleOnline?: () => void;
  compact?: boolean;
}

export function SyncStatusBanner({
  online,
  queue,
  syncing = false,
  onSyncNow,
  onToggleOnline,
  compact = false,
}: SyncStatusBannerProps) {
  const [expanded, setExpanded] = useState(false);
  const [justSynced, setJustSynced] = useState(false);
  const [prevQueueLen, setPrevQueueLen] = useState(queue.length);

  // Trigger brief success notification when queue clears while online
  useEffect(() => {
    if (online && prevQueueLen > 0 && queue.length === 0) {
      setJustSynced(true);
      const timer = setTimeout(() => setJustSynced(false), 3500);
      return () => clearTimeout(timer);
    }
    setPrevQueueLen(queue.length);
  }, [queue.length, online, prevQueueLen]);

  const hasPending = queue.length > 0;
  const isOfflineWithPending = !online && hasPending;

  // Format queue item description for preview
  const formatItemDesc = (item: QueueItem) => {
    const timeStr = item.queuedAt ? new Date(item.queuedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
    switch (item.type) {
      case 'trip_start':
        return {
          title: `Shift Start · ${item.data?.bus || 'Vehicle'}`,
          detail: item.data?.startOdometer != null ? `${item.data.startOdometer} km` : 'No initial ODO',
          time: timeStr,
          icon: 'Play',
        };
      case 'trip_stage':
        return {
          title: `Shift Checkpoint · ${item.stageKey ? item.stageKey.toUpperCase() : 'Stage'}`,
          detail: item.data?.odometer != null ? `${item.data.odometer} km` : 'Watermark photo recorded',
          time: timeStr,
          icon: 'Camera',
        };
      case 'trip_end':
        return {
          title: `Shift Completed · ${item.data?.bus || 'Vehicle'}`,
          detail: item.data?.endOdometer != null ? `Final ODO ${item.data.endOdometer} km` : 'Closed shift',
          time: timeStr,
          icon: 'CheckCircle',
        };
      case 'extra':
        return {
          title: `Extra Trip Log · ${item.data?.bus || 'Bus'}`,
          detail: item.data?.distance != null ? `${item.data.distance} km` : item.data?.note || 'Extra duty',
          time: timeStr,
          icon: 'Route',
        };
      case 'expense':
        return {
          title: `Expense · ${item.data?.type || 'Fuel'}`,
          detail: `${Number(item.data?.amount || 0).toFixed(2)} AED${item.data?.receiptMeta ? ' (receipt attached)' : ''}`,
          time: timeStr,
          icon: 'Wallet',
        };
      default:
        return {
          title: `Driver Log Entry (${item.type})`,
          detail: 'Pending upload to cloud',
          time: timeStr,
          icon: 'Clock',
        };
    }
  };

  // 1. Success indicator after syncing
  if (justSynced && online) {
    return (
      <div className="w-full bg-emerald-950/80 border-b border-emerald-500/30 px-4 py-2 transition-all fade-in">
        <div className="max-w-xl mx-auto flex items-center justify-between text-xs text-emerald-300">
          <div className="flex items-center gap-2 font-medium">
            <span className="flex h-2 w-2 relative">
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
            </span>
            <Icon name="CheckCircle" size={14} className="text-emerald-400" />
            <span>All driver logs synced successfully with AVA Cloud</span>
          </div>
          <span className="text-[10px] text-emerald-400/80 font-mono">100% Synced</span>
        </div>
      </div>
    );
  }

  // 2. Active syncing state
  if (online && (syncing || (hasPending && !compact))) {
    return (
      <div className="w-full bg-sky-950/80 border-b border-sky-500/30 px-4 py-2 transition-all fade-in">
        <div className="max-w-xl mx-auto flex items-center justify-between text-xs text-sky-200">
          <div className="flex items-center gap-2">
            <Icon name="RefreshCw" size={14} className="animate-spin text-sky-400" />
            <span className="font-medium">
              Syncing {queue.length} log{queue.length > 1 ? 's' : ''} to cloud...
            </span>
          </div>
          <span className="text-[10px] text-sky-300/80 font-mono">Uploading</span>
        </div>
      </div>
    );
  }

  // 3. Offline Mode with PENDING logs (PRIMARY REQUIREMENT)
  if (isOfflineWithPending) {
    return (
      <div className="w-full bg-gradient-to-r from-amber-950/90 via-amber-900/80 to-amber-950/90 border-b border-amber-500/40 px-3.5 py-2 shadow-lg backdrop-blur transition-all">
        <div className="max-w-xl mx-auto">
          <div className="flex items-center justify-between gap-2">
            {/* Left side status */}
            <div className="flex items-center gap-2 min-w-0">
              <span className="relative flex h-2.5 w-2.5 shrink-0">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
              </span>
              <Icon name="CloudOff" size={15} className="text-amber-400 shrink-0" />
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-xs font-semibold text-amber-200">
                    Sync Status: Offline
                  </span>
                  <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-mono font-bold border border-amber-500/30">
                    {queue.length} unsynced {queue.length === 1 ? 'log' : 'logs'}
                  </span>
                </div>
                <div className="text-[11px] text-amber-300/80 truncate">
                  Changes safely stored on device.
                </div>
              </div>
            </div>

            {/* Right side quick actions */}
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={() => setExpanded((v) => !v)}
                className="px-2 py-1 rounded-lg bg-amber-950/60 hover:bg-amber-900/60 border border-amber-500/30 text-[11px] text-amber-200 font-medium flex items-center gap-1 cursor-pointer transition-colors"
                title="View unsynced log records"
              >
                <span>Logs</span>
                <Icon
                  name="ChevronDown"
                  size={12}
                  className={`transition-transform duration-200 ${expanded ? 'rotate-180' : ''}`}
                />
              </button>

              <button
                onClick={onSyncNow || onToggleOnline}
                className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 text-[11px] font-bold flex items-center gap-1 shadow cursor-pointer transition-all"
                title="Reconnect network and sync logs"
              >
                <Icon name="RefreshCw" size={11} className={syncing ? 'animate-spin' : ''} />
                <span>Sync Now</span>
              </button>
            </div>
          </div>

          {/* Expandable drawer for review of unsynced items */}
          {expanded && (
            <div className="mt-2.5 pt-2.5 border-t border-amber-500/20 space-y-1.5 fade-in">
              <div className="flex items-center justify-between text-[11px] text-amber-300/70 font-medium">
                <span>Pending Queue ({queue.length} items ready to upload)</span>
                <span className="text-[10px]">Auto-syncs on reconnect</span>
              </div>
              <div className="max-h-48 overflow-y-auto space-y-1 pr-1">
                {queue.map((item, idx) => {
                  const desc = formatItemDesc(item);
                  return (
                    <div
                      key={item.id || idx}
                      className="flex items-center justify-between p-2 rounded-lg bg-slate-900/80 border border-amber-500/20 text-xs"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="p-1 rounded bg-amber-500/10 text-amber-400 shrink-0">
                          <Icon name={desc.icon} size={13} />
                        </div>
                        <div className="min-w-0">
                          <div className="font-semibold text-slate-200 truncate text-[11px]">
                            {desc.title}
                          </div>
                          <div className="text-[10px] text-slate-400 truncate">
                            {desc.detail}
                          </div>
                        </div>
                      </div>
                      <div className="text-[10px] text-amber-400/80 font-mono shrink-0 ml-2">
                        {desc.time || 'Pending'}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // 4. Offline with 0 pending logs
  if (!online && !compact) {
    return (
      <div className="w-full bg-slate-900/80 border-b border-slate-800 px-3.5 py-1.5 backdrop-blur">
        <div className="max-w-xl mx-auto flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-slate-500"></span>
            <Icon name="WifiOff" size={13} className="text-slate-400" />
            <span className="text-[11px]">
              Offline Mode · All actions will be cached locally
            </span>
          </div>
          {onToggleOnline && (
            <button
              onClick={onToggleOnline}
              className="text-[10px] font-semibold text-sky-400 hover:text-sky-300 cursor-pointer"
            >
              Go Online
            </button>
          )}
        </div>
      </div>
    );
  }

  return null;
}
