export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: number;
  image?: {
    mimeType: string;
    data: string; // base64 data url or raw base64
    previewUrl?: string;
  };
  modelUsed?: string;
}

export interface ChatResponse {
  reply: string;
  modelUsed: string;
  note?: string;
}

export interface ExtractedImageData {
  odometer: number | null;
  amount: number | null;
  liters: number | null;
  unitPrice: number | null;
  vendor: string;
}

export interface ImageAnalysisResponse {
  analysis: string;
  modelUsed: string;
  note?: string;
  extracted: ExtractedImageData;
}

export async function sendChatMessage(params: {
  messages: Array<{
    role: 'user' | 'assistant';
    text: string;
    image?: { mimeType: string; data: string };
  }>;
  role?: string;
  modelType?: 'fast' | 'general' | 'complex';
  fleetContext?: any;
}): Promise<ChatResponse> {
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    let errMsg = 'Failed to communicate with Gemini assistant';
    try {
      const data = await res.json();
      if (data?.error) errMsg = data.error;
    } catch {
      // ignore
    }
    throw new Error(errMsg);
  }

  return res.json();
}

export async function analyzeImageWithGemini(params: {
  image: string; // base64 data url
  taskType?: 'odometer' | 'receipt' | 'damage' | 'general';
  prompt?: string;
  bus?: string;
  driverName?: string;
  previousKm?: number | null;
}): Promise<ImageAnalysisResponse> {
  const res = await fetch('/api/analyze-image', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    let errMsg = 'Failed to analyze image with Gemini';
    try {
      const data = await res.json();
      if (data?.error) errMsg = data.error;
    } catch {
      // ignore
    }
    throw new Error(errMsg);
  }

  return res.json();
}
