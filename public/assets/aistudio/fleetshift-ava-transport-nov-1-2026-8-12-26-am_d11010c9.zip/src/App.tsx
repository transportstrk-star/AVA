/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Driver, FleetState, QueueItem } from './types';
import { loadQueue, loadState, saveState } from './utils/storage';
import { LoginScreen } from './components/auth/LoginScreen';
import { DriverPortal } from './components/driver/DriverPortal';
import { AdminPortal } from './components/admin/AdminPortal';
import { syncWithFirestore, testConnection } from './services/firebase';

export default function App() {
  const [state, setState] = useState<FleetState>(loadState);
  const [role, setRole] = useState<'driver' | 'admin' | null>(null);
  const [currentDriver, setCurrentDriver] = useState<Driver | null>(null);
  const [online, setOnline] = useState<boolean>(true);
  const [queue, setQueue] = useState<QueueItem[]>(loadQueue);
  const [firestoreReady, setFirestoreReady] = useState<boolean | null>(null);

  // Initial connection test to Firestore on app boot
  useEffect(() => {
    testConnection().then((ok) => {
      setFirestoreReady(ok);
    });

    // Real-time Firestore sync
    const unsubscribe = syncWithFirestore(setState);
    return () => {
      unsubscribe();
    };
  }, []);

  // Persist state to local storage whenever it changes
  useEffect(() => {
    saveState(state);
  }, [state]);

  const logout = () => {
    setRole(null);
    setCurrentDriver(null);
  };

  return (
    <div className="relative min-h-screen bg-slate-950 font-sans text-slate-100 antialiased selection:bg-sky-500 selection:text-white">
      {/* Cloud Status Indicator in Top-Right (Non-intrusive) */}
      {role && firestoreReady && (
        <div className="fixed top-2.5 right-14 z-30 hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900/80 border border-emerald-500/20 text-[10px] font-medium text-emerald-400 backdrop-blur pointer-events-none">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>Cloud Active</span>
        </div>
      )}

      {/* Main Role Router */}
      {!role && (
        <LoginScreen
          state={state}
          onDriverLogin={(d) => {
            setCurrentDriver(d);
            setRole('driver');
          }}
          onAdminLogin={() => setRole('admin')}
        />
      )}

      {role === 'driver' && currentDriver && (
        <DriverPortal
          state={state}
          setState={setState}
          driver={state.drivers.find((d) => d.id === currentDriver.id) || currentDriver}
          online={online}
          setOnline={setOnline}
          queue={queue}
          setQueue={setQueue}
          onLogout={logout}
        />
      )}

      {role === 'admin' && (
        <AdminPortal
          state={state}
          setState={setState}
          online={online}
          setOnline={setOnline}
          queue={queue}
          setQueue={setQueue}
          onLogout={logout}
        />
      )}
    </div>
  );
}
