import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Generous body limit for image payloads
app.use(express.json({ limit: '40mb' }));
app.use(express.urlencoded({ extended: true, limit: '40mb' }));

// Initialize Google GenAI with required telemetry headers
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Roles system instructions for the multi-turn chatbot
const ROLE_SYSTEM_INSTRUCTIONS: Record<string, string> = {
  dispatcher: `You are the AVA Transport Senior Fleet Dispatcher & Operations Copilot.
You specialize in Dubai & UAE commercial bus fleet logistics, passenger transport, RTA regulations, driver duty hours, route planning between Dubai, Abu Dhabi, Sharjah, and Northern Emirates.
You help drivers and dispatchers solve scheduling problems, compute estimated journey times, verify passenger transfer procedures, and ensure safe, on-time arrivals. Keep answers clear, professional, concise, and operational.`,

  auditor: `You are the AVA Transport Fleet Financial & Compliance Auditor.
You analyze driver shift logs, odometer stage progressions, fuel consumption rates (L/100km or km/L), VAT-compliant fuel receipts from ADNOC, ENOC, Emarat, and maintenance expenses.
You cross-check starting vs ending odometer discrepancies, detect abnormal mileage jumps or zero-distance logs, and provide cost-saving recommendations. Be rigorous, quantitative, and precise.`,

  mechanic: `You are the AVA Transport Master Bus Mechanic & Safety Advisor.
You assist drivers and fleet managers with vehicle health, dashboard warning indicators, tire pressure and tread wear, brake air-system checks, diesel engine diagnostics, air-conditioning cooling performance in high desert temperatures, and pre-trip mechanical inspection protocol. Provide safety-first actionable instructions.`,

  general: `You are AVA Fleet Assistant, an intelligent AI copilot for AVA Transport & Rental in the UAE.
You assist drivers and fleet administrators with shift logging, odometer verification, fuel calculations, vehicle diagnostics, and fleet analytics. Provide polite, practical, and accurate guidance.`,
};

// Map task type or user preference to Gemini model
function getModelName(modelType?: string): string {
  if (modelType === 'fast') return 'gemini-3.1-flash-lite';
  if (modelType === 'complex') return 'gemini-4-argon';
  return 'gemini-3.8-flash';
}

// Helper to retry transient 503/429 errors
async function generateWithRetry(model: string, contents: any, config?: any, retries = 2): Promise<any> {
  let lastError: any;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await ai.models.generateContent({
        model,
        contents,
        config,
      });
    } catch (err: any) {
      lastError = err;
      const errStr = String(err?.message || err || '');
      const isTransient =
        errStr.includes('503') ||
        errStr.includes('429') ||
        errStr.includes('UNAVAILABLE') ||
        errStr.includes('high demand') ||
        errStr.includes('RESOURCE_EXHAUSTED');

      if (isTransient && attempt < retries) {
        await new Promise((resolve) => setTimeout(resolve, 1200 * (attempt + 1)));
        continue;
      }
      throw err;
    }
  }
  throw lastError;
}

// Multi-turn chat endpoint
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const {
      messages = [],
      role = 'dispatcher',
      modelType = 'general',
      fleetContext,
    } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages array is required.' });
    }

    if (!apiKey) {
      return res.status(500).json({
        error: 'GEMINI_API_KEY is not configured in the server environment.',
      });
    }

    let targetModel = getModelName(modelType);
    let systemInstruction = ROLE_SYSTEM_INSTRUCTIONS[role] || ROLE_SYSTEM_INSTRUCTIONS.general;

    if (fleetContext) {
      systemInstruction += `\n\nCURRENT FLEET CONTEXT:\n${typeof fleetContext === 'string' ? fleetContext : JSON.stringify(fleetContext, null, 2)}`;
    }

    // Prepare contents formatted for generateContent with full multi-turn conversation
    const formattedContents = messages.map((m: any) => {
      const parts: any[] = [];
      if (m.image && m.image.data) {
        // Base64 image attachment
        const cleanBase64 = m.image.data.includes(',')
          ? m.image.data.split(',')[1]
          : m.image.data;
        parts.push({
          inlineData: {
            mimeType: m.image.mimeType || 'image/jpeg',
            data: cleanBase64,
          },
        });
      }
      if (m.text) {
        parts.push({ text: m.text });
      }
      return {
        role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
        parts,
      };
    });

    let response;
    let modelUsed = targetModel;
    let note = '';

    try {
      response = await generateWithRetry(targetModel, formattedContents, { systemInstruction });
    } catch (modelError: any) {
      console.warn(`Error generating content with ${targetModel}:`, modelError?.message || modelError);
      // Graceful fallback to gemini-3.8-flash if gemini-4-argon requires billing or has quota constraint
      if (targetModel === 'gemini-4-argon') {
        targetModel = 'gemini-3.8-flash';
        modelUsed = 'gemini-3.8-flash';
        note = 'Fallback to gemini-3.8-flash utilized.';
        response = await generateWithRetry(targetModel, formattedContents, { systemInstruction });
      } else {
        throw modelError;
      }
    }

    const replyText = response.text || 'I processed your request, but no text response was produced.';
    return res.json({
      reply: replyText,
      modelUsed,
      note,
    });
  } catch (err: any) {
    console.error('Chat API Error:', err);
    let userMsg = err?.message || 'Failed to generate AI response.';
    if (userMsg.includes('high demand') || userMsg.includes('503') || userMsg.includes('UNAVAILABLE')) {
      userMsg = 'Gemini AI is momentarily experiencing high demand. Please try sending your message again in a few moments.';
    }
    return res.status(500).json({
      error: userMsg,
    });
  }
});

// Image Analysis endpoint using gemini-4-argon
app.post('/api/analyze-image', async (req: Request, res: Response) => {
  try {
    const {
      image,
      taskType = 'odometer',
      prompt,
      bus,
      driverName,
      previousKm,
    } = req.body;

    if (!image) {
      return res.status(400).json({ error: 'Image data URL or base64 is required.' });
    }

    if (!apiKey) {
      return res.status(500).json({
        error: 'GEMINI_API_KEY is not configured in the server environment.',
      });
    }

    let mimeType = 'image/jpeg';
    let base64Data = image;

    if (image.startsWith('data:')) {
      const match = image.match(/^data:([^;]+);base64,(.+)$/);
      if (match) {
        mimeType = match[1];
        base64Data = match[2];
      }
    }

    let defaultPrompt = '';
    if (taskType === 'odometer') {
      defaultPrompt = `Analyze this vehicle dashboard / instrument cluster photo carefully for AVA Transport & Rental:
1. Identify and extract the exact ODOMETER reading in kilometers (numeric value). Differentiate total ODO from trip meters (Trip A/Trip B).
2. Report the verified km number prominently.
3. Check for any illuminated instrument warning lights (check engine, low fuel, tire pressure TPMS, oil pressure, coolant temperature, ABS, brake system).
4. Verify if the reading is realistic and clear to read.
${previousKm ? `Context: The previous logged reading for this vehicle was ${previousKm} km.` : ''}
${bus ? `Context vehicle plate: ${bus}` : ''}
Please return a concise, clear breakdown:
- **Verified Odometer Reading (km)**: [exact number or "Not detected"]
- **Reading Clarity**: [Clear / Partially Obscured / Blurry]
- **Dashboard Warning Lights**: [None detected / List warnings with safety implications]
- **Summary & Recommendation**: [Short operational status for driver]`;
    } else if (taskType === 'receipt') {
      defaultPrompt = `Analyze this fuel / operational expense receipt or invoice for AVA Transport & Rental:
1. Vendor / Station name (e.g. ADNOC, ENOC, EPPCO, Emarat, Shell, garage name)
2. Fuel type (e.g. Diesel, Special 95, Super 98, E-Plus 91) or expense category (wash, parking, oil)
3. Quantity in Liters (if fuel)
4. Unit price per Liter in AED
5. Total amount paid in AED (including VAT)
6. Date and time on the receipt
7. Invoice / Receipt number or TRN (tax registration number)
Format your response clearly:
- **Vendor**: [Name]
- **Expense Category**: [Fuel / Wash / Parking / Maintenance / Other]
- **Fuel Liters**: [Numeric quantity or N/A]
- **Price per Liter (AED)**: [Numeric price or N/A]
- **Total Amount (AED)**: [Numeric total]
- **Date & Time**: [Extracted timestamp or N/A]
- **Invoice Number**: [Extracted or N/A]
- **Audit Verification**: [Valid receipt / suspicious / missing details]`;
    } else if (taskType === 'damage') {
      defaultPrompt = `Analyze this vehicle photo for inspection, body damage, or physical condition for AVA Transport:
1. Identify vehicle part shown (e.g. front bumper, side panel, tire, interior seats, windshield).
2. Identify any visible damage (scratches, dents, cracks, tire wear, cleanliness issues).
3. Severity rating (Minor cosmetic / Moderate / Critical safety hazard requiring grounding).
4. Recommended maintenance action.`;
    } else {
      defaultPrompt = prompt || 'Analyze this image in detail in the context of commercial fleet management, vehicle condition, and driver operations.';
    }

    const finalPrompt = prompt ? `${defaultPrompt}\n\nAdditional user inquiry: ${prompt}` : defaultPrompt;

    // Use gemini-4-argon as required by the instruction
    let targetModel = 'gemini-4-argon';
    let modelUsed = targetModel;
    let note = '';

    const imagePart = {
      inlineData: {
        mimeType,
        data: base64Data,
      },
    };

    const textPart = {
      text: finalPrompt,
    };

    let response;
    try {
      response = await generateWithRetry(targetModel, { parts: [imagePart, textPart] }, {
        systemInstruction: 'You are an expert AI vehicle inspector and receipt OCR auditor for commercial transport fleets in the UAE.',
      });
    } catch (err: any) {
      console.warn('Error analyzing with gemini-4-argon, falling back to gemini-3.8-flash:', err?.message || err);
      targetModel = 'gemini-3.8-flash';
      modelUsed = 'gemini-3.8-flash';
      note = 'Fallback to gemini-3.8-flash utilized.';
      response = await generateWithRetry(targetModel, { parts: [imagePart, textPart] }, {
        systemInstruction: 'You are an expert AI vehicle inspector and receipt OCR auditor for commercial transport fleets in the UAE.',
      });
    }

    const analysisText = response.text || 'Unable to extract information from the image.';

    // Try extracting numbers for quick-action convenience
    let extractedOdo: number | null = null;
    let extractedAmount: number | null = null;
    let extractedLiters: number | null = null;
    let extractedUnitPrice: number | null = null;
    let extractedVendor = '';

    // Regex extraction heuristics from standard AI output format
    const odoMatch = analysisText.match(/(?:Verified Odometer Reading|Odometer Reading|ODO)[:\s*]+([0-9,.]+)\s*(?:km)?/i);
    if (odoMatch) {
      const clean = odoMatch[1].replace(/,/g, '');
      const parsed = parseFloat(clean);
      if (!isNaN(parsed) && parsed > 0 && parsed < 2000000) {
        extractedOdo = Math.round(parsed);
      }
    }

    const amountMatch = analysisText.match(/(?:Total Amount|Total Paid|Amount)[:\s*]+(?:AED)?\s*([0-9,.]+)/i);
    if (amountMatch) {
      const clean = amountMatch[1].replace(/,/g, '');
      const parsed = parseFloat(clean);
      if (!isNaN(parsed) && parsed > 0) {
        extractedAmount = +(parsed.toFixed(2));
      }
    }

    const litersMatch = analysisText.match(/(?:Fuel Liters|Liters|Quantity)[:\s*]+([0-9,.]+)/i);
    if (litersMatch) {
      const clean = litersMatch[1].replace(/,/g, '');
      const parsed = parseFloat(clean);
      if (!isNaN(parsed) && parsed > 0) {
        extractedLiters = +(parsed.toFixed(2));
      }
    }

    const priceMatch = analysisText.match(/(?:Price per Liter|Unit Price)[:\s*]+(?:AED)?\s*([0-9,.]+)/i);
    if (priceMatch) {
      const clean = priceMatch[1].replace(/,/g, '');
      const parsed = parseFloat(clean);
      if (!isNaN(parsed) && parsed > 0) {
        extractedUnitPrice = +(parsed.toFixed(2));
      }
    }

    const vendorMatch = analysisText.match(/(?:Vendor|Station)[:\s*]+([^\n\r*]+)/i);
    if (vendorMatch) {
      extractedVendor = vendorMatch[1].trim();
    }

    return res.json({
      analysis: analysisText,
      modelUsed,
      note,
      extracted: {
        odometer: extractedOdo,
        amount: extractedAmount,
        liters: extractedLiters,
        unitPrice: extractedUnitPrice,
        vendor: extractedVendor,
      },
    });
  } catch (err: any) {
    console.error('Image Analysis API Error:', err);
    return res.status(500).json({
      error: err?.message || 'Failed to analyze image.',
    });
  }
});

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    geminiConfigured: !!apiKey,
    timestamp: new Date().toISOString(),
  });
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    // Mount Vite middleware in development
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AVA Fleet Server running on http://0.0.0.0:${PORT} (Gemini AI ready)`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
